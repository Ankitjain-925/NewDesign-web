
import React from 'react';

class Virtualindex extends React.Component {
    render() {
      return <h1>Hello</h1>
    };
  }

 export default Virtualindex;