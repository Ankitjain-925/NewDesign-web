export const COMETCHAT_CONSTANTS = {
    APP_ID: '220824e717b58ac',
    REGION: 'eu',
    AUTH_KEY: 'fc177a4e50f38129dca144f6270b91bfc9444736'
}