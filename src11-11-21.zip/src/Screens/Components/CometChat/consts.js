export const COMETCHAT_CONSTANTS = {
    APP_ID: process.env.REACT_APP_APPID,
    REGION: 'eu',
    AUTH_KEY: process.env.REACT_APP_APIKEY
}